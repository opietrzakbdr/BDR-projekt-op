// @see https://www.detectadblock.com
try {
  window.sessionStorage.setItem("_oab", "none")
} catch (e) {}
